==========================================================================
MTP Figures Archive — Prashant Gupta, MSc Physics, IIT Kharagpur (2026)
Project: Variational Quantum Eigensolver for Molecular Ground States
Supervisor: Prof. Sonjoy Majumder | Roll: 24PH40033
==========================================================================

This folder contains all figures and plots from the entire MTP project,
organised by notebook/study. Total: 51 figures across 20 subfolders.

FOLDER GUIDE
────────────────────────────────────────────────────────────────────────
A_Baseline_File1_VQE_Ansatz_Comparison
   Figures from File 1 notebook: baseline comparison of UCCSD, TwoLocal,
   and HEA-TI ansatze on H2 and LiH PES. COBYLA optimizer, D=4.
   Source: File 1_VQE_Final_Complete.ipynb + figures/ folder

B_Improved_HEA-TI_File2
   File 2 notebook: improved HEA-TI with L-BFGS-B optimizer and
   warm-starting. LiH error: 27.45 → 0.000 mHa.
   Source: File 2_VQE_Final_Complete_Improved.ipynb + figures/ folder

C_Optimizer_Study_File3
   File 3 notebook: five-optimizer benchmark (L-BFGS-B, CG, SLSQP,
   COBYLA, ADAM) on HEA-TI at D=6 (H2) and D=8 (LiH). Includes
   error comparison, PES, and convergence rate plots.
   Source: File 3_VQE_Final_Complete_HEA-TI.ipynb + figures/ folder

D_Noisy_Simulation_File4
   File 4 notebook: HEA-TI under depolarising noise (p1=0.1%, p2=1%).
   Ablation study: depth D x t_d strategy (fixed vs learnable).
   Learnable t_d: 29.87 → 1.05 mHa on LiH at zero extra circuit cost.
   Source: File 4_VQE_Noisy_HEA-TI.ipynb + figures/ folder

E_Direction1_Expressivity_Gap_ExperimentB
   Experiment B: noiseless expressivity gap ΔEgap for all 4 molecules
   (H2, LiH, BeH2, H2O) with 8 seeds. Central predictor metric.
   Source: Direction1_Extended_Final.ipynb

F_Direction1_Noise_Threshold_Sweep_ExperimentA
   Experiment A: sweep of CX error rate p2 from 0.0001% to 0.02%
   for H2 and LiH showing fixed vs learnable t_d crossover behavior.
   Source: Direction1_Extended_Final.ipynb + v2 Final.ipynb

G_Direction1_Molecular_Generalisation_ExperimentC
   Experiment C: validation on all 4 molecules at p2=0.001%.
   Shows ΔEgap as predictor (4/4 accuracy) and optimiser cost.
   Source: Direction1_Extended_Final.ipynb + v2 Final.ipynb

H_Direction1_Unified_Summary
   Publication-quality 2×2 unified summary combining all three
   experiments (A, B, C) in a single figure.
   Source: Direction1_Extended_Final.ipynb + v2 Final.ipynb

I_Direction1_PES_Sweep
   PES sweep over 10 H2 and 8 LiH geometries. Shows geometry
   dependence of ΔEgap and LiH dissociation crossover.
   Source: Direction1_Extended_Final.ipynb

J_Direction1_LOO_Validation
   Leave-one-out cross-validation of ΔEgap predictor.
   R²=0.97, LOO accuracy 4/4, threshold ΔEgap*≈7.83 mHa.
   Source: Direction1_Extended_Final.ipynb

K_Direction1_Convergence_Curves
   8-seed convergence curves for all 4 molecules, fixed vs learnable t_d.
   Top row=fixed, bottom row=learnable. Shows landscape bimodality.
   Source: Direction1_Extended_Final.ipynb

L_Publication_Upgrades_Fix1_LiH_PES
   Fix 1: Complete LiH PES extended to 4.5 Å with interpolated
   ionic-to-covalent crossover at R*≈2.980 Å.
   Source: Direction1_Publication_Upgrades_v2.ipynb (both versions)

M_Publication_Upgrades_Fix2_Gradient
   Fix 2: Corrected t_d gradient magnitude at t_d=0 (not at random init).
   R²=0.199, no significant trend vs ΔEgap — retracts earlier claim.
   Also includes optimal learned t_d values per molecule.
   Source: Publication_Upgrades_v2.ipynb + Direction1_Extended_Final.ipynb

N_Publication_Upgrades_Fix3_Convergence_Metrics
   Fix 3: Quantitative convergence (FPT, AUC50, P_esc) for all 8 configs.
   Fixed t_d: P_esc=0 for LiH/BeH2/H2O. Learnable: P_esc=1.0 in ~100 evals.
   Source: Direction1_Publication_Upgrades_v2.ipynb (both versions)

O_Publication_Upgrades_Fix4_Calibrated_ADPD
   Fix 4: Calibrated AD+PD noise (γ_2q=7.03e-6, fidelity-matched to
   depolarising). Predictor accuracy 4/4 — up from 3/4 in uncalibrated run.
   Source: Direction1_Publication_Upgrades_v2.ipynb

P_Publication_Upgrades_Fix5_Budget_Benchmark
   Fix 5: Budget-matched fair benchmark. Oracle scan uses same evaluation
   budget as learnable run. LiH/BeH2/H2O: 28–30x more evals for oracle.
   Source: Direction1_Publication_Upgrades_v2.ipynb

Q_Publication_Upgrades_Fix6_Regression_CI
   Fix 6: OLS regression with bootstrap + parametric 95% CIs.
   Slope=1.203 [0.574,1.831], threshold=7.83 mHa [-23.3,+38.9 mHa CI].
   Source: Direction1_Publication_Upgrades_v2.ipynb (both versions)

R_Publication_Upgrades_Fix7_H2_Fragility
   Fix 7: H2 seed-scaling (P_esc=1/8) and heuristic SNR analysis.
   Shows H2 is near classification boundary — fundamentally fragile.
   Source: Direction1_Publication_Upgrades_v2.ipynb (both versions)

S_Presentation_Slides
   Key slides extracted from MTP_Enhanced.pdf presentation:
   title, introduction, VQE framework, HEA-TI circuit diagram (Zhuang
   et al. PRA 2024), four-stage study overview, baseline results.

T_Additional_Direction1_Figures
   Additional Direction1 figures: fair oracle benchmark t_d landscape,
   uncalibrated AD+PD noise comparison, SLSQP second optimizer results.
   Source: Direction1_Extended_Final.ipynb

==========================================================================
KEY RESULTS SUMMARY
==========================================================================
Chemical accuracy threshold: 1.6 mHa = 1 kcal/mol

Molecules:  H2 (4q, STO-3G) | LiH (6q, 2e/3o) | BeH2 (6q) | H2O (6q)
Circuit:    D=4 layers, CX gates: H2=96, others=240
Seeds:      8 independent random initialisations
Optimizer:  L-BFGS-B (noisy runs), StatevectorEstimator (noiseless)

ΔEgap predictor: 4/4 accuracy (depolarising) | 4/4 (calibrated AD+PD)
BeH2 improvement: 44.02 → 1.34 mHa (33x) with zero seed variance
LiH PES crossover: R* ≈ 2.980 Å (interpolated ionic-to-covalent)
Regression: R²=0.971, threshold ΔEgap*=7.83 mHa
Budget ratio: learnable t_d uses 28–30x fewer evaluations vs oracle scan
==========================================================================
